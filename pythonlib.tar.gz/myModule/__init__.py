from .myModule import *

from .textproc import *
from .fileproc import *
