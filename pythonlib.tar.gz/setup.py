from distutils.core import setup
setup(
    name = "pythonlib mine",
    packages = ['myModule','work_utils'],
    version = "1.0.0",
    description = 'my own stuff for python',
    author = "Yo Sato",
    author_email = "yosato16@gmail.com",
#    download_url = "https://github.com/yosato/myProgs/pythonlib/pythonlib.tar.gz",
    classifiers = [
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        ],
    long_description = """\
just stuff

"""
)
